CSC Business Manager PWA starter

Includes offline-first app, CSC icon, local device storage, PIN lock, daily reports, CSV export, JSON backup/restore.

Default PIN: 1234. Change it immediately in Settings & Backup.

For installable PWA behavior, host these files on a trusted HTTPS static host, then open the URL in Chrome on Android and choose Install app / Add to Home screen. Opening index.html directly works as a local HTML app but service-worker offline caching and PWA installation require HTTPS or localhost.

This is not a signed Android APK and is not an official CSC government application. Data is stored locally in the browser on this device; clearing browser data can erase it. Export backups regularly.
